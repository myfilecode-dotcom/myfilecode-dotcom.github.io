# Fomo — Promo Kit for Affiliates

**Product:** Fomo — Social proof notification widget builder
**Price:** $49 one-time
**Your link:** https://whop.com/myfileapps/fomo (replace with your affiliate URL)
**Commission:** 50% per sale = ~$24.50

---

## Screenshots

- `home.png` — All widgets dashboard with widget name, served count, status
- `widget-editor.png` — Notification list editor with live widget preview
- `widget-preview.png` — Widget preview rendering with brand styling

---

## Twitter / X (10 posts)

1. ```
Social proof widgets cost $79/mo on Provely / Fomo.com.
This template = same thing. $49 one-time. {your_link}
   ```

2. ```
"Sarah from London just purchased Pro Plan."
That little widget = +12% conversion on most landing pages.
This template builds it for you. $49.
{your_link}
   ```

3. ```
- 5 templates: purchase / signup / review / visitor / custom
- Position, theme, accent color
- Loop / random order toggle
- Embed-ready widget builder
$49 one-time. {your_link}
   ```

4. ```
Built social proof widgets for 4 client landing pages with this $49 template.
Each one converts 8-15% better. Math.
{your_link}
   ```

5. ```
Stop paying Provely $79/mo for "trust badges".
Fomo template = $49 once. Self-hosted. Full source.
{your_link}
   ```

6. ```
Indie devs / agency owners:
This is the indie alternative to Fomo.com / Provely / TrustPulse.
$49. {your_link}
   ```

7. ```
Best $49 I spent for my SaaS landing page:
Real-time-feel social proof. Multiple widgets per site.
{your_link}
   ```

8. ```
Fomo template — full Next.js source, $49 one-time.
Build social proof notification widgets, 5 templates, themes, embed.
{your_link}
   ```

9. ```
Conversion rate optimization for solopreneurs:
$49 social proof widget template > $79/mo subscription.
{your_link}
   ```

10. ```
Tired of "free" widgets that brand your site?
This template is yours. Source code. No "powered by" tag.
$49. {your_link}
    ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: Built (well, bought) a Fomo.com clone for $49 — running it on 3 of my landing pages

Spent $49 on Fomo template — full Next.js source. Multiple widget configs, 5 notification templates (purchase / signup / review / visitor / custom), live preview, position / theme settings.

Embedded on 3 landing pages. Conversion bumped 8-12% on each.

{your_link}
```

### r/Entrepreneur

```
Title: $49 one-time social proof template instead of $79/mo Provely

Just used Fomo template — full source code. Builds the "Sarah from London just purchased" widgets that boost conversion.

For founders who don't want to pay subscriptions for what is basically a configurable popup.

{your_link}
```

### r/marketing

```
Title: Self-hosted social proof widget — $49 one-time

For solo marketers / agencies: Fomo is a Next.js template. Build unlimited social proof widgets, 5 notification templates, themes, position, embed.

Full source. Replaces $79/mo Fomo.com / Provely subscriptions.

{your_link}
```

### r/passive_income

```
Title: Bought a $49 social proof template, charging clients $99 per widget setup

Found this template. Offering "your custom social proof widget" service to local businesses for $99 setup. 6 deals month 1.

{your_link}
```

### r/webdev

```
Title: Social proof widget template (Next.js + TS) — $49 one-time

Clean code:
- Multiple widget configs
- 5 templates (purchase / signup / review / visitor / custom)
- Position, theme, accent color, border radius, shadow
- Loop / random order
- Display time + delay between
- CSV import notifications
- Live preview + embed code

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you run a SaaS / landing page.

Found a $49 one-time social proof widget template. 5 templates, themes, embed-ready. Full Next.js source.

Probably cheaper than your Provely subscription. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $49 social proof template.

It's solid: multi-widget builder, 5 templates, live preview, embed. Self-hosted.

{your_link}
```

### Repost in groups
```
For solo founders / marketers:

Fomo template — $49 one-time
Self-hosted social proof widgets
5 templates, themes, embed-ready

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s — show widget popping up "Sarah from London purchased Pro Plan"]
"This little widget bumps conversion 8-15%."

[3-10s — show widget editor with notifications]
"This template builds it. Multiple widgets, 5 templates, themes."

[10-20s — show position / theme / accent color picker]
"Position. Theme. Accent. Loop. Random order. All configurable."

[20-27s — show 3 different landing pages with widgets]
"One $49 purchase. Unlimited widgets. Forever."

[27-30s — CTA]
"$49 one-time. Link in bio."
```

---

## Hashtags

```
#socialproof #conversionrate #cro #saas #indiedev #nextjs #typescript #onetimepurchase #marketing #microsaas #webdev #fomo #landingpages
```

---

## Where to post (priority order)

1. **Twitter/X** — reply to "Provely is too expensive" / SaaS marketing threads
2. **Reddit** — r/SideProject, r/Entrepreneur, r/marketing, r/SaaS, r/webdev
3. **Indie Hackers** — show & tell with widget preview
4. **TikTok** — "POV: bumping conversion 12% with this widget"
5. **Telegram** — marketing / SaaS founder channels
6. **LinkedIn** — CRO / growth marketers
7. **Facebook groups** — SaaS founders, agency owners
