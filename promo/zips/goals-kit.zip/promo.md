# Goals — Promo Kit for Affiliates

**Product:** Goals — Annual goal tracker with milestones and year review
**Price:** $25 one-time
**Your link:** https://whop.com/myfileapps/goals (replace with your affiliate URL)
**Commission:** 50% per sale = ~$12.5

---

## Screenshots

- `home.png` — Goals dashboard with year progress, categories, and goal cards
- `review.png` — Year review with stats, insights, and milestones reached
- `add.png` — Goal creation flow with category, milestones, sub-tasks

---

## Twitter / X (10 posts)

1. ```
Built a annual goal tracker that doesn't suck.
No subscription. No ads. Just code you own.
$25 one-time → run it forever.
{your_link}
   ```

2. ```
Stop paying $9/mo for productivity apps.
Goals: year goals, milestones, sub-tasks, category breakdown, year review.
Self-hosted. Yours forever.
$25. {your_link}
   ```

3. ```
Productivity nerds and goal setters — this is your sign.
Full Next.js source code. year goals, milestones, sub-tasks, category breakdown, year review.
Deploy on Vercel in 5 mins.
$25 once. {your_link}
   ```

4. ```
You can charge clients for personal coaching or accountability programs using this app.
Or run it for yourself.
Either way — $25, you own the code.
{your_link}
   ```

5. ```
Set 5-10 yearly goals, track progress, hit milestones, get a year-end review.
Add it to your productivity side project.
$25 one-time. {your_link}
   ```

6. ```
indie devs: stop building from scratch.
Goals template = $25, deploys in minutes, real users will pay $5/mo to use it.
{your_link}
   ```

7. ```
Bought Goals template last week, deployed it, 3 friends already using it daily.
$25. Forever.
{your_link}
   ```

8. ```
Best $25 I spent this month — full Next.js productivity app.
year goals, milestones, sub-tasks, category breakdown, year review.
{your_link}
   ```

9. ```
Goals app for sale. One time $25.
year goals, milestones, sub-tasks, category breakdown, year review.
Built in TypeScript, runs anywhere.
{your_link}
   ```

10. ```
Tired of "productivity apps" that just want your subscription?
This one is yours forever for $25.
Source code included.
{your_link}
    ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: I bought a Next.js productivity app template and reskinned it in a weekend

Spent $25 on this Goals template — full source. year goals, milestones, sub-tasks, category breakdown, year review. Runs entirely in localStorage, no backend.

Used it as the base for my own productivity side project. Took 2 evenings to rebrand. Already getting paying users.

Link: {your_link}
```

### r/productivity

```
Title: $25 one-time SaaS templates instead of building from scratch

Just used "Goals" — productivity app template. year goals, milestones, sub-tasks, category breakdown, year review. Full Next.js source code, no subscription on the template itself, no monthly fees.

Way faster than starting from a Figma file. Anyone else using template marketplaces to ship faster?

{your_link}
```

### r/webdev

```
Title: Productivity app template (Next.js + TS) — $25 one-time

Sharing because it saved me a week:
- Annual goal tracker with categories
- Milestones (25/50/75/100%) and sub-tasks
- Year progress bar with days remaining
- Year review with insights and achievements
- Color-coded categories
- Full TypeScript source

Clean code, zero dependencies on weird APIs. localStorage only.

{your_link}
```

### r/getdisciplined

```
Title: Bought a $25 productivity app template, charging $5/mo subscriptions

Found this template, modified it for paid users, set up Stripe. ~30 customers in 2 weeks. The template paid for itself in 4 sales.

Anyone else flipping these one-time templates into recurring SaaS?

{your_link}
```

### Niche subs

```
Title: One-time $25 productivity app — anyone tried building service with it?

Found this Next.js template — year goals, milestones, sub-tasks, category breakdown, year review. $25 one-time, no subscription.

Curious if anyone has launched a paid productivity service using a template like this.

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you're into [productivity / indie dev / passive income].

Found a $25 one-time Next.js productivity app template. year goals, milestones, sub-tasks, category breakdown, year review. Full source code.

Could be a good base for your own thing. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $25 productivity template via my link, so I'm sharing widely.

It's actually solid: year goals, milestones, sub-tasks, category breakdown, year review. TypeScript Next.js, deploys on Vercel.

{your_link}
```

### Repost in groups
```
For anyone building productivity side projects:

Goals template — $25 one-time, no subscription
year goals, milestones, sub-tasks, category breakdown, year review
Full Next.js source

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s]
"New Year resolutions die in February — here's why."

[3-10s]
"This template breaks goals into milestones and sub-tasks. You actually finish them."

[10-20s]
"Categories: health, career, financial, learning, creative. Year progress bar at the top."

[20-27s]
"Year review page: insights, stats, what you actually achieved. Self-hosted."

[27-30s — CTA]
"$25 one-time. Link in bio."
```

---

## Hashtags

```
#goals #productivity #yearinreview #indiedev #nextjs #saas #sidehustle #webdev #typescript #onetimepurchase #newyear #habits
```

---

## Where to post (priority order)

1. **TikTok** — record screen, post 1/day
2. **Reddit** — r/SideProject, r/productivity, r/webdev, r/getdisciplined
3. **Twitter/X** — thread + reply under productivity accounts
4. **Telegram** — productivity channels, indie hacker channels
5. **Instagram** — niche meme accounts (DM offer)
6. **Pinterest** — pin a screenshot, link to your URL
7. **Facebook** — productivity groups, indie hacker groups

