# Pitch — Promo Kit for Affiliates

**Product:** Pitch — Deck builder for founders and investors
**Price:** $29 one-time
**Your link:** https://whop.com/myfileapps/pitch (replace with your affiliate URL)
**Commission:** 50% per sale = ~$14.50

---

## Screenshots

- `deck.png` — deck
- `home.png` — home
- `present.png` — present

---

## Twitter / X (10 posts)

1. ```
Built a startup pitch app that doesn't suck.
No subscription. No ads. Just code you own.
$29 one-time → run it forever.
{your_link}
   ```

2. ```
Stop paying $9/mo for tools that should be one-time.
Pitch: deck builder for founders and investors.
Self-hosted. Yours forever.
$29. {your_link}
   ```

3. ```
indie devs — stop building from scratch.
Pitch template = $29, deploys in minutes, real users will pay $5/mo to use it.
{your_link}
   ```

4. ```
You can charge clients $87 for startup services using this app.
Or run it for yourself.
Either way — $29, you own the code.
{your_link}
   ```

5. ```
Deck builder for founders and investors for any team.
Add it to your side project today.
$29 one-time. {your_link}
   ```

6. ```
Bought Pitch template last week, deployed it on Vercel in 5 mins, already getting users.
$29. Forever.
{your_link}
   ```

7. ```
Best $29 I spent this month — full Next.js startup app.
Deck builder for founders and investors.
{your_link}
   ```

8. ```
Pitch app for sale. One time $29.
Deck builder for founders and investors.
Built in TypeScript, runs anywhere.
{your_link}
   ```

9. ```
Tired of "startup apps" that just want your subscription?
This one is yours forever for $29.
Source code included.
{your_link}
   ```

10. ```
Pitch: $29 one-time, no subscription.
Deck builder for founders and investors.
Source code yours. Deploy anywhere.
{your_link}
   ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: I bought a Next.js startup app template and reskinned it in a weekend

Spent $29 on this Pitch template — full source. Deck builder for founders and investors.

Used it as the base for my own side project. Took 2 evenings to rebrand. Already getting users.

Link: {your_link}
```

### r/Entrepreneur

```
Title: $29 one-time SaaS templates instead of building from scratch

Just used "Pitch" — deck builder for founders and investors. Full Next.js source code, no monthly fees on the template itself.

Way faster than starting from a Figma file. Anyone else using template marketplaces to ship faster?

{your_link}
```

### r/webdev

```
Title: Startup app template (Next.js + TS) — $29 one-time

Sharing because it saved me a week:
- Deck builder for founders and investors
- Full TypeScript source
- Deploys to Vercel in minutes

Clean code, zero weird API dependencies. localStorage-first.

{your_link}
```

### r/passive_income

```
Title: Bought a $29 startup app template, charging $5/mo subscriptions

Found this template, modified it for paid users, set up Stripe. ~30 customers in 2 weeks. The template paid for itself in 2 sales.

Anyone else flipping these one-time templates into recurring SaaS?

{your_link}
```

### r/indiehackers

```
Title: Pitch template — $29 one-time, no subscription

Found this Next.js template — full source. Deck builder for founders and investors.

Curious if anyone has launched a paid service using a template like this.

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you're into [startup / indie dev / passive income].

Found a $29 one-time Next.js startup app template. deck builder for founders and investors. Full source code.

Could be a good base for your own thing. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $29 template via my link, so I'm sharing widely.

It's actually solid: deck builder for founders and investors. TypeScript Next.js, deploys on Vercel.

{your_link}
```

### Repost in groups
```
For anyone building startup / spirituality / indie side projects:

Pitch template — $29 one-time, no subscription
Deck builder for founders and investors
Full Next.js source

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s — show the home screen]
"You're paying $9/month for startup??"

[3-10s — show the main feature in action]
"This template gives you the same thing — deck builder for founders and investors."

[10-20s — show second feature screen]
"All the features. No subscription. Source code yours."

[20-27s — show third feature]
"Self-hosted. Your data. Your code."

[27-30s — CTA]
"$29 one-time. Link in bio."
```

---

## Hashtags

```
#startup #pitch #indiedev #nextjs #saas #sidehustle #webdev #typescript #onetimepurchase #buildinpublic
```

---

## Where to post (priority order)

1. **TikTok** — record screen, add trending audio, post 1/day
2. **Reddit** — r/SideProject, r/Entrepreneur, r/webdev, r/founder-tools, r/passive_income
3. **Twitter/X** — thread + reply under startup accounts
4. **Telegram** — startup channels, indie hacker channels
5. **Instagram** — niche meme accounts (DM offer)
6. **Pinterest** — pin the main screenshot, link to your URL
7. **Facebook** — startup groups, indie hacker groups
