# Vault — Promo Kit for Affiliates

**Product:** Vault — Digital legacy app with dead man's switch
**Price:** $29 one-time
**Your link:** https://whop.com/myfileapps/vault (replace with your affiliate URL)
**Commission:** 50% per sale = ~$14.5

---

## Screenshots

- `home.png` — Vault dashboard with messages
- `people.png` — Trusted recipients management
- `settings.png` — Dead man's switch settings and check-in

---

## Twitter / X (10 posts)

1. ```
Built vault — digital legacy app with dead man's switch.
No subscription. No ads. Just code you own.
$29 one-time → run it forever.
{your_link}
   ```

2. ```
Stop paying monthly for legacy tools.
Vault: digital legacy app with dead man's switch.
Self-hosted. Yours forever.
$29. {your_link}
   ```

3. ```
Privacy-conscious userss — this is for you.
Full Next.js source code. Digital legacy app with dead man's switch.
Deploy on Vercel in 5 mins.
$29 once. {your_link}
   ```

4. ```
You can charge clients to use this app.
Or run it for yourself.
Either way — $29, you own the code.
{your_link}
   ```

5. ```
Digital legacy app with dead man's switch.
Add it to your stack today.
$29 one-time. {your_link}
   ```

6. ```
indie devs: stop building from scratch.
Vault template = $29, deploys in minutes, real users will pay to use it.
{your_link}
   ```

7. ```
Bought Vault template last week, deployed it the same day.
$29. Forever.
{your_link}
   ```

8. ```
Best $29 I spent this month — full Next.js legacy app.
Digital legacy app with dead man's switch.
{your_link}
   ```

9. ```
Vault app for sale. One time $29.
Digital legacy app with dead man's switch.
Built in TypeScript, runs anywhere.
{your_link}
   ```

10. ```
Tired of subscription legacy tools?
This one is yours forever for $29.
Source code included.
{your_link}
    ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: I bought a Next.js legacy app template for $29 and shipped in a weekend

Spent $29 on this Vault template — full source. Digital legacy app with dead man's switch. Runs entirely in localStorage, no backend.

Used it as the base for my own side project. Took 2 evenings to rebrand. Already has paying users.

Link: {your_link}
```

### r/privacy

```
Title: $29 one-time SaaS templates instead of building from scratch

Just used "Vault" — legacy app template. Digital legacy app with dead man's switch. Full Next.js source code, no subscription on the template, no monthly fees.

Way faster than starting from a Figma file. Anyone else using template marketplaces to ship faster?

{your_link}
```

### r/selfhosted

```
Title: Legacy app template (Next.js + TS) — $29 one-time

Sharing because it saved me a week:
- Digital legacy app with dead man's switch
- Full TypeScript source
- localStorage only, no backend dependencies
- Deploys on Vercel in minutes

{your_link}
```

### r/EstatePlanning

```
Title: Bought a $29 legacy template, charging users for access

Found this template, modified it for paid users, set up Stripe. The template paid for itself within days.

Anyone else flipping these one-time templates into recurring SaaS?

{your_link}
```

### r/webdev

```
Title: One-time $29 legacy app — anyone tried building a service with it?

Found this Next.js template — Digital legacy app with dead man's switch. $29 one-time, no subscription.

Curious if anyone has launched a paid service using a template like this.

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you're into [privacy-conscious users].

Found a $29 one-time Next.js legacy app template. Digital legacy app with dead man's switch. Full source code.

Could be a good base for your own thing. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $29 legacy template via my link, so I'm sharing widely.

It's actually solid: Digital legacy app with dead man's switch. TypeScript Next.js, deploys on Vercel.

{your_link}
```

### Repost in groups
```
For anyone building privacy-conscious users side projects:

Vault template — $29 one-time, no subscription
Digital legacy app with dead man's switch
Full Next.js source

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s — show the home screen]
"You're paying monthly for legacy apps??"

[3-10s — show feature page]
"This template gives you the same thing. Digital legacy app with dead man's switch."

[10-20s — show another feature]
"Self-hosted. Your data, your code."

[20-27s — show stats / detail view]
"Full TypeScript source. Deploys on Vercel."

[27-30s — CTA]
"$29 one-time. Link in bio."
```

---

## Hashtags

```
#privacy #selfhosted #legacy #indiedev #nextjs #estate
```

---

## Where to post (priority order)

1. **Twitter/X** — thread + reply under privacy-conscious users accounts
2. **Reddit** — r/SideProject, r/privacy, r/selfhosted, r/EstatePlanning, r/webdev
3. **IndieHackers** — post in relevant section
4. **Telegram** — privacy-conscious users channels, indie hacker channels
5. **TikTok** — record screen, hook with the problem this app solves
6. **Pinterest** — pin the home screenshot, link to your URL
7. **Facebook** — privacy-conscious users groups, indie hacker groups
