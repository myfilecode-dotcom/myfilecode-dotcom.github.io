# Card — Promo Kit for Affiliates

**Product:** Card — Digital business card with QR code and vCard export
**Price:** $19 one-time
**Your link:** https://whop.com/myfileapps/card (replace with your affiliate URL)
**Commission:** 50% per sale = ~$9.50

---

## Screenshots

- `export.png` — export
- `home.png` — home
- `preview.png` — preview

---

## Twitter / X (10 posts)

1. ```
Built a dev-tools card app that doesn't suck.
No subscription. No ads. Just code you own.
$19 one-time → run it forever.
{your_link}
   ```

2. ```
Stop paying $9/mo for tools that should be one-time.
Card: digital business card with qr code and vcard export.
Self-hosted. Yours forever.
$19. {your_link}
   ```

3. ```
indie devs — stop building from scratch.
Card template = $19, deploys in minutes, real users will pay $5/mo to use it.
{your_link}
   ```

4. ```
You can charge clients $57 for dev-tools services using this app.
Or run it for yourself.
Either way — $19, you own the code.
{your_link}
   ```

5. ```
Digital business card with QR code and vCard export for any team.
Add it to your side project today.
$19 one-time. {your_link}
   ```

6. ```
Bought Card template last week, deployed it on Vercel in 5 mins, already getting users.
$19. Forever.
{your_link}
   ```

7. ```
Best $19 I spent this month — full Next.js dev-tools app.
Digital business card with QR code and vCard export.
{your_link}
   ```

8. ```
Card app for sale. One time $19.
Digital business card with QR code and vCard export.
Built in TypeScript, runs anywhere.
{your_link}
   ```

9. ```
Tired of "dev-tools apps" that just want your subscription?
This one is yours forever for $19.
Source code included.
{your_link}
   ```

10. ```
Card: $19 one-time, no subscription.
Digital business card with QR code and vCard export.
Source code yours. Deploy anywhere.
{your_link}
   ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: I bought a Next.js dev-tools app template and reskinned it in a weekend

Spent $19 on this Card template — full source. Digital business card with QR code and vCard export.

Used it as the base for my own side project. Took 2 evenings to rebrand. Already getting users.

Link: {your_link}
```

### r/Entrepreneur

```
Title: $19 one-time SaaS templates instead of building from scratch

Just used "Card" — digital business card with qr code and vcard export. Full Next.js source code, no monthly fees on the template itself.

Way faster than starting from a Figma file. Anyone else using template marketplaces to ship faster?

{your_link}
```

### r/webdev

```
Title: Dev app template (Next.js + TS) — $19 one-time

Sharing because it saved me a week:
- Digital business card with QR code and vCard export
- Full TypeScript source
- Deploys to Vercel in minutes

Clean code, zero weird API dependencies. localStorage-first.

{your_link}
```

### r/passive_income

```
Title: Bought a $19 dev-tools app template, charging $5/mo subscriptions

Found this template, modified it for paid users, set up Stripe. ~30 customers in 2 weeks. The template paid for itself in 2 sales.

Anyone else flipping these one-time templates into recurring SaaS?

{your_link}
```

### r/indiehackers

```
Title: Card template — $19 one-time, no subscription

Found this Next.js template — full source. Digital business card with QR code and vCard export.

Curious if anyone has launched a paid service using a template like this.

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you're into [dev-tools / indie dev / passive income].

Found a $19 one-time Next.js dev-tools app template. digital business card with qr code and vcard export. Full source code.

Could be a good base for your own thing. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $19 template via my link, so I'm sharing widely.

It's actually solid: digital business card with qr code and vcard export. TypeScript Next.js, deploys on Vercel.

{your_link}
```

### Repost in groups
```
For anyone building dev-tools / spirituality / indie side projects:

Card template — $19 one-time, no subscription
Digital business card with QR code and vCard export
Full Next.js source

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s — show the home screen]
"You're paying $9/month for dev-tools??"

[3-10s — show the main feature in action]
"This template gives you the same thing — digital business card with qr code and vcard export."

[10-20s — show second feature screen]
"All the features. No subscription. Source code yours."

[20-27s — show third feature]
"Self-hosted. Your data. Your code."

[27-30s — CTA]
"$19 one-time. Link in bio."
```

---

## Hashtags

```
#devtools #card #indiedev #nextjs #saas #sidehustle #webdev #typescript #onetimepurchase #buildinpublic
```

---

## Where to post (priority order)

1. **TikTok** — record screen, add trending audio, post 1/day
2. **Reddit** — r/SideProject, r/Entrepreneur, r/webdev, r/developer-tools, r/passive_income
3. **Twitter/X** — thread + reply under dev-tools accounts
4. **Telegram** — dev-tools channels, indie hacker channels
5. **Instagram** — niche meme accounts (DM offer)
6. **Pinterest** — pin the main screenshot, link to your URL
7. **Facebook** — dev-tools groups, indie hacker groups
