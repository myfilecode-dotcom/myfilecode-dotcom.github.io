# Ledger — Promo Kit for Affiliates

**Product:** Ledger — Invoice generator, live preview, payment tracking
**Price:** $29 one-time
**Your link:** https://whop.com/myfileapps/ledger-3f (replace with your affiliate URL)
**Commission:** 50% per sale = ~$14.5

---

## Screenshots

- `home.png` — Invoice dashboard with collected, outstanding, overdue stats
- `invoice.png` — Invoice editor with live preview and line items
- `clients.png` — Clients list with totals and recent invoices

---

## Twitter / X (10 posts)

1. ```
Built a invoice generator that doesn't suck.
No subscription. No ads. Just code you own.
$29 one-time → run it forever.
{your_link}
   ```

2. ```
Stop paying $9/mo for invoicing apps.
Ledger: invoice builder, live preview, payment tracking, client manager.
Self-hosted. Yours forever.
$29. {your_link}
   ```

3. ```
Freelancers and small studios — this is your sign.
Full Next.js source code. invoice builder, live preview, payment tracking, client manager.
Deploy on Vercel in 5 mins.
$29 once. {your_link}
   ```

4. ```
You can charge clients for your own invoicing tool or a client billing service using this app.
Or run it for yourself.
Either way — $29, you own the code.
{your_link}
   ```

5. ```
Stop paying $20/mo for invoicing apps. Send unlimited invoices, free.
Add it to your invoicing side project.
$29 one-time. {your_link}
   ```

6. ```
indie devs: stop building from scratch.
Ledger template = $29, deploys in minutes, real users will pay $5/mo to use it.
{your_link}
   ```

7. ```
Bought Ledger template last week, deployed it, 3 friends already using it daily.
$29. Forever.
{your_link}
   ```

8. ```
Best $29 I spent this month — full Next.js invoicing app.
invoice builder, live preview, payment tracking, client manager.
{your_link}
   ```

9. ```
Ledger app for sale. One time $29.
invoice builder, live preview, payment tracking, client manager.
Built in TypeScript, runs anywhere.
{your_link}
   ```

10. ```
Tired of "invoicing apps" that just want your subscription?
This one is yours forever for $29.
Source code included.
{your_link}
    ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: I bought a Next.js invoicing app template and reskinned it in a weekend

Spent $29 on this Ledger template — full source. invoice builder, live preview, payment tracking, client manager. Runs entirely in localStorage, no backend.

Used it as the base for my own invoicing side project. Took 2 evenings to rebrand. Already getting paying users.

Link: {your_link}
```

### r/freelance

```
Title: $29 one-time SaaS templates instead of building from scratch

Just used "Ledger" — invoicing app template. invoice builder, live preview, payment tracking, client manager. Full Next.js source code, no subscription on the template itself, no monthly fees.

Way faster than starting from a Figma file. Anyone else using template marketplaces to ship faster?

{your_link}
```

### r/webdev

```
Title: Invoicing app template (Next.js + TS) — $29 one-time

Sharing because it saved me a week:
- Invoice builder with line items, tax, currency
- Live PDF-style preview while editing
- Status tracking: draft / sent / paid / overdue
- Client list with totals
- Auto-incrementing invoice numbers
- Business info reused across invoices

Clean code, zero dependencies on weird APIs. localStorage only.

{your_link}
```

### r/smallbusiness

```
Title: Bought a $29 invoicing app template, charging $5/mo subscriptions

Found this template, modified it for paid users, set up Stripe. ~30 customers in 2 weeks. The template paid for itself in 4 sales.

Anyone else flipping these one-time templates into recurring SaaS?

{your_link}
```

### Niche subs

```
Title: One-time $29 invoicing app — anyone tried building service with it?

Found this Next.js template — invoice builder, live preview, payment tracking, client manager. $29 one-time, no subscription.

Curious if anyone has launched a paid invoicing service using a template like this.

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you're into [invoicing / indie dev / passive income].

Found a $29 one-time Next.js invoicing app template. invoice builder, live preview, payment tracking, client manager. Full source code.

Could be a good base for your own thing. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $29 invoicing template via my link, so I'm sharing widely.

It's actually solid: invoice builder, live preview, payment tracking, client manager. TypeScript Next.js, deploys on Vercel.

{your_link}
```

### Repost in groups
```
For anyone building invoicing side projects:

Ledger template — $29 one-time, no subscription
invoice builder, live preview, payment tracking, client manager
Full Next.js source

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s]
"Why are you paying $20/mo for invoicing??"

[3-10s]
"Build invoices with line items, tax, due date — live PDF preview."

[10-20s]
"Track paid, sent, overdue at a glance. Client list with totals."

[20-27s]
"Self-hosted. Your data, your code. Send unlimited invoices forever."

[27-30s — CTA]
"$29 one-time. Link in bio."
```

---

## Hashtags

```
#freelancer #invoicing #invoice #indiedev #nextjs #saas #sidehustle #webdev #typescript #onetimepurchase #smallbusiness #accounting
```

---

## Where to post (priority order)

1. **TikTok** — record screen, post 1/day
2. **Reddit** — r/SideProject, r/freelance, r/webdev, r/smallbusiness
3. **Twitter/X** — thread + reply under invoicing accounts
4. **Telegram** — invoicing channels, indie hacker channels
5. **Instagram** — niche meme accounts (DM offer)
6. **Pinterest** — pin a screenshot, link to your URL
7. **Facebook** — invoicing groups, indie hacker groups

