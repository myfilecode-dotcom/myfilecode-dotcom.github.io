# Shout — Promo Kit for Affiliates

**Product:** Shout — Collect and display testimonials, no monthly fees
**Price:** $39 one-time
**Your link:** https://whop.com/myfileapps/shout (replace with your affiliate URL)
**Commission:** 50% per sale = ~$19.5

---

## Screenshots

- `home.png` — Testimonial admin dashboard
- `wall.png` — Public testimonial wall to embed
- `manage.png` — Approve, edit, and curate incoming testimonials

---

## Twitter / X (10 posts)

1. ```
Built shout — collect and display testimonials, no monthly fees.
No subscription. No ads. Just code you own.
$39 one-time → run it forever.
{your_link}
   ```

2. ```
Stop paying monthly for testimonial tools.
Shout: collect and display testimonials, no monthly fees.
Self-hosted. Yours forever.
$39. {your_link}
   ```

3. ```
Saas founderss — this is for you.
Full Next.js source code. Collect and display testimonials, no monthly fees.
Deploy on Vercel in 5 mins.
$39 once. {your_link}
   ```

4. ```
You can charge clients to use this app.
Or run it for yourself.
Either way — $39, you own the code.
{your_link}
   ```

5. ```
Collect and display testimonials, no monthly fees.
Add it to your stack today.
$39 one-time. {your_link}
   ```

6. ```
indie devs: stop building from scratch.
Shout template = $39, deploys in minutes, real users will pay to use it.
{your_link}
   ```

7. ```
Bought Shout template last week, deployed it the same day.
$39. Forever.
{your_link}
   ```

8. ```
Best $39 I spent this month — full Next.js testimonial app.
Collect and display testimonials, no monthly fees.
{your_link}
   ```

9. ```
Shout app for sale. One time $39.
Collect and display testimonials, no monthly fees.
Built in TypeScript, runs anywhere.
{your_link}
   ```

10. ```
Tired of subscription testimonial tools?
This one is yours forever for $39.
Source code included.
{your_link}
    ```

---

## Reddit (5 posts)

### r/SideProject

```
Title: I bought a Next.js testimonial app template for $39 and shipped in a weekend

Spent $39 on this Shout template — full source. Collect and display testimonials, no monthly fees. Runs entirely in localStorage, no backend.

Used it as the base for my own side project. Took 2 evenings to rebrand. Already has paying users.

Link: {your_link}
```

### r/Entrepreneur

```
Title: $39 one-time SaaS templates instead of building from scratch

Just used "Shout" — testimonial app template. Collect and display testimonials, no monthly fees. Full Next.js source code, no subscription on the template, no monthly fees.

Way faster than starting from a Figma file. Anyone else using template marketplaces to ship faster?

{your_link}
```

### r/SaaS

```
Title: Testimonial app template (Next.js + TS) — $39 one-time

Sharing because it saved me a week:
- Collect and display testimonials, no monthly fees
- Full TypeScript source
- localStorage only, no backend dependencies
- Deploys on Vercel in minutes

{your_link}
```

### r/webdev

```
Title: Bought a $39 testimonial template, charging users for access

Found this template, modified it for paid users, set up Stripe. The template paid for itself within days.

Anyone else flipping these one-time templates into recurring SaaS?

{your_link}
```

### r/Freelance

```
Title: One-time $39 testimonial app — anyone tried building a service with it?

Found this Next.js template — Collect and display testimonials, no monthly fees. $39 one-time, no subscription.

Curious if anyone has launched a paid service using a template like this.

{your_link}
```

---

## Telegram / Discord DM (3 templates)

### Cold DM #1
```
Hey — saw you're into [SaaS founders].

Found a $39 one-time Next.js testimonial app template. Collect and display testimonials, no monthly fees. Full source code.

Could be a good base for your own thing. {your_link}
```

### Cold DM #2
```
Quick one — I get 50% commission if you grab this $39 testimonial template via my link, so I'm sharing widely.

It's actually solid: Collect and display testimonials, no monthly fees. TypeScript Next.js, deploys on Vercel.

{your_link}
```

### Repost in groups
```
For anyone building SaaS founders side projects:

Shout template — $39 one-time, no subscription
Collect and display testimonials, no monthly fees
Full Next.js source

{your_link}
```

---

## TikTok / Reels script (30s)

```
[Hook 0-3s — show the home screen]
"You're paying monthly for testimonial apps??"

[3-10s — show feature page]
"This template gives you the same thing. Collect and display testimonials, no monthly fees."

[10-20s — show another feature]
"Self-hosted. Your data, your code."

[20-27s — show stats / detail view]
"Full TypeScript source. Deploys on Vercel."

[27-30s — CTA]
"$39 one-time. Link in bio."
```

---

## Hashtags

```
#testimonials #saas #indiedev #nextjs #webdev #socialproof
```

---

## Where to post (priority order)

1. **Twitter/X** — thread + reply under SaaS founders accounts
2. **Reddit** — r/SideProject, r/Entrepreneur, r/SaaS, r/webdev, r/Freelance
3. **IndieHackers** — post in relevant section
4. **Telegram** — SaaS founders channels, indie hacker channels
5. **TikTok** — record screen, hook with the problem this app solves
6. **Pinterest** — pin the home screenshot, link to your URL
7. **Facebook** — SaaS founders groups, indie hacker groups
